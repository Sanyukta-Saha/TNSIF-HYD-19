package bike;

public class ride {

	public static void main(String[] args) {
		bmw b = new bmw();
		b.speed();
		b.color();
		b.model();
		Ducati d= new Ducati();
		d.speed();
		d.color();
		d.model();
		Kawasaki k = new Kawasaki();
		k.speed();
		k.color();
		k.model();

	}

}

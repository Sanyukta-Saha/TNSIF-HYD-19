package com.sriindu;

public class Assign1 {

	public static void main(String[] args) {
		System.out.println("Hello....welcome to java class");

	}

}

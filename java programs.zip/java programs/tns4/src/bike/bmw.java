package bike;

public class bmw {
	public void speed() {
		System.out.println("speed is : 249kmph");
		}
	public void color() {
		System.out.println("color is : blue");
	}
	public void model() {
		System.out.println("model is :XM");
	}
}
class Ducati {
	public void speed() {
		System.out.println("speed is :299 kmph");
		}
	public void color() {
		System.out.println("color is : red");
	}
	public void model() {
		System.out.println("model is :panigale V4");
	}
}
class Kawasaki {
	public void speed() {
		System.out.println("speed is :280kmph");
		}
	public void color() {
		System.out.println("color is : green");
	}
	public void model() {
		System.out.println("model is : Z H2");
	}
}


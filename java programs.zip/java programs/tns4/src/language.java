import java.lang.*;
public class language {

	public static void main(String[] args) {
		 String s = "Hello, Welcome to java!";
		 int n = 9;
		 
	        System.out.println(s);
	        System.out.println("Length of the string: " + s.length());
	        System.out.println("Substring from index 7: " + s.substring(7));
	        System.out.println("Uppercase: " + s.toUpperCase());
	        System.out.println("Lowercase: " + s.toLowerCase());
	        System.out.println("Square root : " + Math.sqrt(n));
	        System.out.println("Sine of : " + Math.sin(n));
	        System.out.println("Cosine of : " + Math.cos(n));
	}

}

package com.coreconcepts.abstractclass;

public class Nonveg extends Person {
	

	@Override
	public void eat() {
		System.out.println("Eats Nonveg");
	}

}

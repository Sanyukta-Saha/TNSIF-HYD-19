package com.coreconcepts.abstractclass;

public abstract class Person {
	
	public void speak() {
		System.out.println("Share his/her thougths");
	}
	
	public abstract void eat();

}

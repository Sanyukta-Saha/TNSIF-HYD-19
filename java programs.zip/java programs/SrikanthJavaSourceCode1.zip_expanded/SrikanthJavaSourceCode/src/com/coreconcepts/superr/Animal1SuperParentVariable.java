package com.coreconcepts.superr;

public class Animal1SuperParentVariable {
	
	String color="white";

}

package com.coreconcepts.multipleinheritence;

public class MultipleFrontend {
	
	public void responsive(String str) {
	    System.out.println(str + " can also be used as frontend.");
	  }

}

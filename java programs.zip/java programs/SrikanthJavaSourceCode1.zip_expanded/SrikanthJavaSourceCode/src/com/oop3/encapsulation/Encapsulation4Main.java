package com.oop3.encapsulation;

public class Encapsulation4Main {
	
	public static void main(String[] args) {
		Encapsulation4 e4 = new Encapsulation4();
		e4.setAge(25);
		e4.setGender("Male");
		e4.setName("John");
		
		System.out.println(e4.getAge());
		System.out.println(e4.getGender());
		System.out.println(e4.getName());
		
	}

}

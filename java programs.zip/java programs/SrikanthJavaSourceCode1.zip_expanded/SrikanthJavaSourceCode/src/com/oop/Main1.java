package com.oop;

public class Main1 {
	
	public static void main(String[] args) {
		Car1 c= new Car1();
		c.speed=40;
		System.out.println(c.speed);
		// c.drivers = "seated";    can't executed since it is private
		
	}

}



package com.oop;

public class Car1 {
	
	private String doors;
	private String engine;
	private String drivers;
	public int speed ;
	
	
	public static void main(String[] args) {
		Car1 c= new Car1();
		c.speed=40;
		System.out.println(c.speed);
		c.drivers = "seated";   
		System.out.println(c.drivers);
		c.engine = "on";   
		System.out.println(c.engine);
		c.drivers = "close";   
		System.out.println(c.doors);
		
		
	}

}


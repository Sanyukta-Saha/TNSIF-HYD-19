package com.oop2.inheritence;

public class DogProtected extends AnimalProtected {
	
	 public void getInfo() {
		    System.out.println("My name is " + name);
		  }

}

package com.oop2.inheritence;

public class MultilevelProgrammer2 extends MultilevelPerson1{
	
	String getCodinglanguage() {
		return "Java";
	}

}

package com.oop2.inheritence;

public interface MultipleBackend {
	
	//abstract method
	public void connectServer() ;

}

package com.oop2.inheritence;

public class MainSuper {
	
	public static void main(String[] args) {
		
		
		DogSuper labrador = new DogSuper();
		labrador.eat();
		labrador.bark();
		
	}

}

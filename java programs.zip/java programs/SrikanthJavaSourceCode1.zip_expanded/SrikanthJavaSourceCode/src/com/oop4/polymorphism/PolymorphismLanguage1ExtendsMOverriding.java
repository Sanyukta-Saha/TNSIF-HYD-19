package com.oop4.polymorphism;

public class PolymorphismLanguage1ExtendsMOverriding extends PolymorphismLanguage1MOverriding {
	
	@Override
	  public void displayInfo() {
	    System.out.println("Java Programming Language");
	  }

}

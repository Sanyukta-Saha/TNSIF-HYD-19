/**
 * 
 */
/**
 * 
 */
module samp {
}
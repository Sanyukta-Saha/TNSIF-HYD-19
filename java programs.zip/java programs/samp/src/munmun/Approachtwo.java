package munmun;

public class Approach {
	int id = 9;
	static String name = "Sanyukta";
	void display() {
		
	}
	static String display1() {
		return "hello";
			}
}
 class sample{
	public static void main(String[] args) {
		int sal= 200;
		Approach ap	= new Approach();
		System.out.println(ap.id);
		System.out.println(Approach.name);
		System.out.println(sal);
		ap.display();
		System.out.println(Approach.display1());
			
}

}

		
	}

}

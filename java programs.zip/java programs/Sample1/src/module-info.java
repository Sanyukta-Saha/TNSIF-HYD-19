/**
 * 
 */
/**
 * 
 */
module Sample1 {
}
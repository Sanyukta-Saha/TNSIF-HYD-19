package sanyukta;

public class Assign {
	int id = 9;
	static String name = "Sanyukta";
	void display() {
	
	}
	static string display1() {
		return "hello";
	}
	}
	public static void main(String[] args) {
		int sal= 200;
	Assign asg	= new Assign);
	System.out.println(asg.a);
	System.out.println(Assign.name);
	System.out.println(name);
	System.out.println(sal);
	asg.display();
	System.out.println(Assign.display1());
	
	
	
	
	 
	}
}
